<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'jbi_test');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '3W0T9x-kaDeu1r_0RrR}G3*)_dkK-lZsVZDG~jc.ozU(I -M#sHW:$0uiF:!.Qfh');
define('SECURE_AUTH_KEY',  '_UWNY54Ks4FV#;dJkmd]?bPCw-+<:j{yaNg{XtARtWV&XgMP1*u|cO=|*X,f|_tA');
define('LOGGED_IN_KEY',    '6i,+4]c+-nUUWYpPCS1Hn;n&wnqnAIUews|Ik+S>N:~/oy8Iv%>7CK8[7JZ7qC_(');
define('NONCE_KEY',        'HmJv#H[9|AUI|-d6),GZ=Eom&Tw*B[VX`ID?YQp=nFeXwRs/eD:!nvoq,`1g9|!i');
define('AUTH_SALT',        '=AU.iDDMzUV]q9^13X71l4GxG@2owJ]/H}k*af/Ja>el-6qx7a=*wN[k%h$yV&Ih');
define('SECURE_AUTH_SALT', '9ezb&2p7d]d&IC#.;IfL`C=<Q;JA:T&hSf5g7;>zgj!}RNHA85Vm)34t7pc[yG(p');
define('LOGGED_IN_SALT',   'KLg[u%kd9.doe_~}:Epn0a~sCT4+oK&XzaZ8(of9rZ<IKS3.^WwJ;4}/-Rv9ze$!');
define('NONCE_SALT',       '2V1]JAl:Onpc:kg&*JzEp*u0SMtrgT<=mwjX?aPdRYw{XLcryS)jQjdg*%e1vK#q');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
